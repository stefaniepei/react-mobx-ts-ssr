module.exports = {
  type: "mongodb",
  host: "172.16.0.240",
  port: 27017,
  database: "official-site",
  synchronize: true,
  logging: false,
  entities: [
    __dirname + "/build/entity/**/*.js"
  ]
}
