import {GatewayContext, MiddlewareNext} from "sasdn";
import { Logger }from 'log4js';
import getLogger from '../../lib/logger';
import mongodbLogic from '../common/mongodbLogic';
import * as recruit_pb from "../../proto/recruit/recruit_pb";
import { Recruit } from '../../entity/recruit/recruit';
import { RecruitDetail } from '../../entity/recruit/recruitDetail';

const logger: Logger = getLogger();

interface GetJobListRequest {
  body: recruit_pb.GetJobListRequest.AsObject;
}

interface GetJobInfoRequest {
  body: recruit_pb.GetJobInfoRequest.AsObject;
}

interface SetJobStopRequest {
  body: recruit_pb.SetJobStopRequest.AsObject;
}

interface PublishJobRequest {
  body: recruit_pb.PublishJobRequest.AsObject;
}

interface AddJobRequest {
  body: recruit_pb.AddJobRequest.AsObject;
}

interface EditJobRequest {
  body: recruit_pb.EditJobRequest.AsObject;
}


export namespace recruitLogic {

  export async function getJobList(ctx: GatewayContext, next?: MiddlewareNext, params?: GetJobListRequest): Promise<recruit_pb.GetJobListResponse> {
    if (ctx === null) {
      throw new Error('koa context is null');
    }

    let message = new Recruit();
    const response = new recruit_pb.GetJobListResponse();

    return Promise.resolve(response);

  }

  export async function getJobInfo(ctx: GatewayContext, next?: MiddlewareNext, params?: GetJobInfoRequest): Promise<recruit_pb.GetJobInfoResponse> {
    if (ctx === null) {
      throw new Error('koa context is null');
    }
    return
  }

  export async function addJob (ctx: GatewayContext, next?: MiddlewareNext, params?: AddJobRequest): Promise<recruit_pb.AddJobResponse> {
    return
  }

  export async function setJobStop(ctx: GatewayContext, next?: MiddlewareNext, params?: SetJobStopRequest): Promise<recruit_pb.SetJobStopResponse> {
    return;
  }

  export async function publishJob(ctx: GatewayContext, next?: MiddlewareNext, params?: PublishJobRequest): Promise<recruit_pb.PublishJobResponse> {
    return;
  }

  export async function editJob(ctx: GatewayContext, next?: MiddlewareNext, params?: EditJobRequest): Promise<recruit_pb.EditJobResponse> {
    return;
  }



}
