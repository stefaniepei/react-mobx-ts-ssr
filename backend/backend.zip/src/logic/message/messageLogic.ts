import {GatewayContext, MiddlewareNext} from "sasdn";
import { Logger }from 'log4js';
import getLogger from '../../lib/logger';
import mongodbLogic from '../common/mongodbLogic';
import { contactEmail } from '../../configs/config'
import * as message_pb from "../../proto/message/message_pb";
import { Message } from '../../entity/message/message';
import { sendMail , getEmailTitle, getEmailContent} from "../common/sendEmail";

const logger: Logger = getLogger();

interface CreateLeavingMessageRequest {
  body: message_pb.CreateLeavingMessageRequest.AsObject;
}

interface GetMessageListRequest {
  body: message_pb.GetMessageListRequest.AsObject;
}

interface DealMessageRequest {
  body: message_pb.DealMessageRequest.AsObject;
}

export namespace messageLogic {

  export async function createLeavingMessage(ctx: GatewayContext, next?: MiddlewareNext, params?: CreateLeavingMessageRequest): Promise<message_pb.CreateLeavingMessageResponse> {
    if (ctx === null) {
      throw new Error('koa context is null');
    }

    let message = new Message();
    message = Object.assign(message, params.body);
    message.createDate = new Date();
    const leaveResult = await mongodbLogic.createViaModel(Message, message);
    logger.info('leavingMessageResult: ', leaveResult);

    const userEmail = params.body.userEmail || '';
    //  response
    const response = new message_pb.CreateLeavingMessageResponse();
    const resData = new message_pb.ResMessageData();
    let resMessage = new message_pb.Message();

    const messageList = [];
    resMessage.setMessageId(leaveResult.id);
    resMessage.setUserName(leaveResult.userName || '');
    resMessage.setUserEmail(leaveResult.userEmail || '')
    resMessage.setUserPhone(leaveResult.userPhone || '');
    resMessage.setUserAddress(leaveResult.userAddress || '');

    resMessage.setGameType(leaveResult.gameType || '');
    resMessage.setMessageStatus(leaveResult.messageStatus || 0);
    resMessage.setCreateDate(leaveResult.createDate || '');
    resMessage.setUserExperience(leaveResult.userExperience || '');
    resMessage.setGameInfo(leaveResult.gameInfo || '');
    resMessage.setMessage(leaveResult.message || '');
    resMessage.setMessageType(leaveResult.messageType || '');
    messageList.push(resMessage);

    resData.setCount(1);
    resData.setDataList(messageList);
    response.setStatus(0);
    response.setMessage('success');
    response.setData(resData);

    process.nextTick(() => {
      const emailTitle = getEmailTitle(leaveResult.messageType, params.body);
      const emailContent = getEmailContent(leaveResult.messageType, params.body);
      sendMail(contactEmail, userEmail, emailTitle, emailContent);
    })

    return Promise.resolve(response);
  }

  export async function dealLeavingMessage(ctx: GatewayContext, next?: MiddlewareNext, params?: DealMessageRequest): Promise<message_pb.DealMessageResponse> {
    if (ctx === null) {
      throw new Error('koa context is null');
    }
    return
  }

  export async function getMessageList(ctx: GatewayContext, next?: MiddlewareNext, params?: GetMessageListRequest): Promise<message_pb.GetMessageListResponse> {
    return
  };

}
