import * as nodeMailer from 'nodemailer';
import * as nodeMailerSmtpTransport from 'nodemailer-smtp-transport';

export function getEmailTitle(type: number, content: any): string {
  let emailTitle: string;
  switch (type) {
    case 1:
      emailTitle = `【官网·孵化】来自${content.userName || ''}的邮件`;
      break
    case 2:
      emailTitle = `【官网·发行】来自${content.userName || ''}的邮件`;
      break
    case 3:
      emailTitle = `【官网·品牌公关】来自${content.userName || ''}的邮件`;
      break
    default:
      emailTitle = `【官网·其他】来自${content.userName || ''}的邮件`;
      break
  }
  return emailTitle;
}

export function getEmailContent(type: number, content: any): string {
  let emailContent: string;
  switch (type) {
    case 1:
      emailContent = '制作人姓名：' + (content.userName || '') + '<br/> 邮箱：' + (content.userEmail || '') + ' <br/> 手机号：' + (content.userPhone || '')
        + '<br/> 地址： ' + (content.userAddress || '') + '<br/> 游戏类型：' + (content.gameType || '') + '<br/> 制作人工作经历：' + (content.userExperience || '')
        + '<br/> 游戏介绍：' + (content.gameInfo || '');
      break;
    default:
      emailContent = '联系人姓名：' + (content.userName || '') + '<br/> 联系人邮箱：' + (content.userEmail || '') + '<br/> 手机号：' + (content.userPhone || '')
        + '<br/> 留言信息： ' + (content.message || '');
      break;
  }
  return emailContent;
}

const transportOptions: nodeMailerSmtpTransport.SmtpOptions = {
  host: "smtp.exmail.qq.com", // 主机
  secure: true,
  port: 465,
  auth: {
    user: "business@shinezone.com", // 账号
    pass: "nxiDMiieU6HLoj8L" // 密码
  }
}

export function sendMail (mailto: string, mailfrom: string, title: string, content: any) {
  let smtpTransport = nodeMailer.createTransport(nodeMailerSmtpTransport(transportOptions));
  let mailtofinal = mailto;
  let mailOptions = {
    from: "business@shinezone.com", // 发件地址
    to: mailtofinal, // 收件列表
    subject: title, // 标题
    html: "以下邮件内容,来自于炫踪网站的'联系我们'页面的提交<p>"+content+" </p><p>FROM:"+mailfrom+"</p>" // html 内容
  }
  // 发送邮件
  smtpTransport.sendMail(mailOptions, function(error, response){
    if(error){
      console.log('发送邮件异常： ', error)
      return false;
    }else{
      console.log('发送邮件success')
      smtpTransport.close();
      return true;
    }
  });


}
