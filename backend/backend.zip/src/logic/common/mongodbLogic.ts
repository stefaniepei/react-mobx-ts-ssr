import { mongodbInstance } from '../../lib/mongodbClient';

class MongodbLogic {
  constructor() {}

  async findViaModel (modelName, condition, type) {
    let findResult: any;
    if (type === "one") {
      findResult = await mongodbInstance.getMongoRepository(modelName).findOne(condition);
    } else {
      findResult = await mongodbInstance.getMongoRepository(modelName).find(condition);
    }
    return findResult;
  }

  async countViaModel (modelName, condition) {
    return await mongodbInstance.getRepository(modelName).count(condition);
  }
  async createViaModel(modelName, modelInstance) {
    return await mongodbInstance.getRepository(modelName).save(modelInstance);
  }

  async updateViaModel (modelName, condition, updateValue, type) {
    let updateResult: any;
    if (type === "one") {
      updateResult = await mongodbInstance.getMongoRepository(modelName).updateOne(condition, updateValue);
    } else {
      updateResult = await mongodbInstance.getMongoRepository(modelName).updateMany(condition, updateValue);
    }
    console.log('updateResult: ', updateResult.modifiedCount)
  }

  async deleteViaModel (modelName, condition, type) {
    let deleteResult: any;
    if (type === "one") {
      deleteResult = await mongodbInstance.getMongoRepository(modelName).deleteOne(condition);
    } else {
      deleteResult = await mongodbInstance.getMongoRepository(modelName).deleteMany(condition);
    }
    console.log('deleteResult: ', deleteResult.modifiedCount)
  }

}

const mongodbLogic = new MongodbLogic();
export default mongodbLogic
