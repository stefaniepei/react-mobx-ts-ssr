import "reflect-metadata";
import {createConnection, Connection} from "typeorm";

export let mongodbInstance: Connection;

export async function initMongodbClient() {
  mongodbInstance = await createConnection();
}
