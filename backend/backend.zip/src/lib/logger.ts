import * as log4js from 'log4js';
import logConfig from '../configs/logConfig';

log4js.configure(logConfig);

function getLogger(name?: string){
  let logger: log4js.Logger;
  switch (name) {
    case "errorLog":
      logger = log4js.getLogger(name);
      break;
    default:
      logger = log4js.getLogger();
      break;
  }
  return logger;
}

export default getLogger;


