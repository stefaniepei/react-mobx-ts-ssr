export const contactEmail = "incubation@shinezone.com";  //  表单提交联系人邮箱
