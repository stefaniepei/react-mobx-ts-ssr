import {Configuration} from 'log4js'

const logConfig: Configuration = {
  appenders: {
    console: {
      type: 'console'
    },
    file: {
      type: 'file',
      filename: './logs/application.log',
      maxLogSize: 104800,
      backups: 100
    },
    date_file: {
      type: 'dateFile',
      filename: "./logs/date",
      alwaysIncludePattern: true,
      pattern: "-yyyy-MM-dd.log"
    }
  },
  categories: {
    default: {appenders: ['console'], level: 'info'},
    errorLog: {appenders: ['console', 'file', 'date_file'], level: 'error'}
  },
  pm2: true
};

export default logConfig;


