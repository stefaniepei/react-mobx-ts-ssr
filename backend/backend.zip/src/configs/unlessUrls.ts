export const unlessUrls: {} = {
  path: [] = [
    /\/v1\/user\/getUserList/i
  ]
}

