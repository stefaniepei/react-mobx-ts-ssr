// package: message
// file: message/message.proto

import * as jspb from "google-protobuf";

export class Message extends jspb.Message { 
    getMessageId(): string;
    setMessageId(value: string): void;

    getUserName(): string;
    setUserName(value: string): void;

    getUserEmail(): string;
    setUserEmail(value: string): void;

    getUserPhone(): string;
    setUserPhone(value: string): void;

    getUserAddress(): string;
    setUserAddress(value: string): void;

    getGameType(): string;
    setGameType(value: string): void;

    getMessageStatus(): number;
    setMessageStatus(value: number): void;

    getDealUserName(): string;
    setDealUserName(value: string): void;

    getDealDate(): string;
    setDealDate(value: string): void;

    getCreateDate(): string;
    setCreateDate(value: string): void;

    getUserExperience(): string;
    setUserExperience(value: string): void;

    getGameInfo(): string;
    setGameInfo(value: string): void;

    getMessage(): string;
    setMessage(value: string): void;

    getMessageType(): number;
    setMessageType(value: number): void;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Message.AsObject;
    static toObject(includeInstance: boolean, msg: Message): Message.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: Message, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Message;
    static deserializeBinaryFromReader(message: Message, reader: jspb.BinaryReader): Message;
}

export namespace Message {
    export type AsObject = {
        messageId: string,
        userName: string,
        userEmail: string,
        userPhone: string,
        userAddress: string,
        gameType: string,
        messageStatus: number,
        dealUserName: string,
        dealDate: string,
        createDate: string,
        userExperience: string,
        gameInfo: string,
        message: string,
        messageType: number,
    }
}

export class ResMessageData extends jspb.Message { 
    clearDataList(): void;
    getDataList(): Array<Message>;
    setDataList(value: Array<Message>): void;
    addData(value?: Message, index?: number): Message;

    getCount(): number;
    setCount(value: number): void;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): ResMessageData.AsObject;
    static toObject(includeInstance: boolean, msg: ResMessageData): ResMessageData.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: ResMessageData, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): ResMessageData;
    static deserializeBinaryFromReader(message: ResMessageData, reader: jspb.BinaryReader): ResMessageData;
}

export namespace ResMessageData {
    export type AsObject = {
        dataList: Array<Message.AsObject>,
        count: number,
    }
}

export class CreateLeavingMessageRequest extends jspb.Message { 
    getUserName(): string;
    setUserName(value: string): void;

    getUserEmail(): string;
    setUserEmail(value: string): void;

    getUserPhone(): string;
    setUserPhone(value: string): void;

    getUserAddress(): string;
    setUserAddress(value: string): void;

    getGameType(): string;
    setGameType(value: string): void;

    getUserExperience(): string;
    setUserExperience(value: string): void;

    getGameInfo(): string;
    setGameInfo(value: string): void;

    getMessageType(): number;
    setMessageType(value: number): void;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): CreateLeavingMessageRequest.AsObject;
    static toObject(includeInstance: boolean, msg: CreateLeavingMessageRequest): CreateLeavingMessageRequest.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: CreateLeavingMessageRequest, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): CreateLeavingMessageRequest;
    static deserializeBinaryFromReader(message: CreateLeavingMessageRequest, reader: jspb.BinaryReader): CreateLeavingMessageRequest;
}

export namespace CreateLeavingMessageRequest {
    export type AsObject = {
        userName: string,
        userEmail: string,
        userPhone: string,
        userAddress: string,
        gameType: string,
        userExperience: string,
        gameInfo: string,
        messageType: number,
    }
}

export class CreateLeavingMessageResponse extends jspb.Message { 
    getStatus(): number;
    setStatus(value: number): void;

    getMessage(): string;
    setMessage(value: string): void;


    hasData(): boolean;
    clearData(): void;
    getData(): ResMessageData | undefined;
    setData(value?: ResMessageData): void;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): CreateLeavingMessageResponse.AsObject;
    static toObject(includeInstance: boolean, msg: CreateLeavingMessageResponse): CreateLeavingMessageResponse.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: CreateLeavingMessageResponse, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): CreateLeavingMessageResponse;
    static deserializeBinaryFromReader(message: CreateLeavingMessageResponse, reader: jspb.BinaryReader): CreateLeavingMessageResponse;
}

export namespace CreateLeavingMessageResponse {
    export type AsObject = {
        status: number,
        message: string,
        data?: ResMessageData.AsObject,
    }
}

export class GetMessageListRequest extends jspb.Message { 
    getMessageType(): number;
    setMessageType(value: number): void;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): GetMessageListRequest.AsObject;
    static toObject(includeInstance: boolean, msg: GetMessageListRequest): GetMessageListRequest.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: GetMessageListRequest, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): GetMessageListRequest;
    static deserializeBinaryFromReader(message: GetMessageListRequest, reader: jspb.BinaryReader): GetMessageListRequest;
}

export namespace GetMessageListRequest {
    export type AsObject = {
        messageType: number,
    }
}

export class GetMessageListResponse extends jspb.Message { 
    getStatus(): number;
    setStatus(value: number): void;

    getMessage(): string;
    setMessage(value: string): void;


    hasData(): boolean;
    clearData(): void;
    getData(): ResMessageData | undefined;
    setData(value?: ResMessageData): void;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): GetMessageListResponse.AsObject;
    static toObject(includeInstance: boolean, msg: GetMessageListResponse): GetMessageListResponse.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: GetMessageListResponse, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): GetMessageListResponse;
    static deserializeBinaryFromReader(message: GetMessageListResponse, reader: jspb.BinaryReader): GetMessageListResponse;
}

export namespace GetMessageListResponse {
    export type AsObject = {
        status: number,
        message: string,
        data?: ResMessageData.AsObject,
    }
}

export class DealMessageRequest extends jspb.Message { 
    getMessageId(): string;
    setMessageId(value: string): void;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): DealMessageRequest.AsObject;
    static toObject(includeInstance: boolean, msg: DealMessageRequest): DealMessageRequest.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: DealMessageRequest, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): DealMessageRequest;
    static deserializeBinaryFromReader(message: DealMessageRequest, reader: jspb.BinaryReader): DealMessageRequest;
}

export namespace DealMessageRequest {
    export type AsObject = {
        messageId: string,
    }
}

export class DealMessageResponse extends jspb.Message { 
    getStatus(): number;
    setStatus(value: number): void;

    getMessage(): string;
    setMessage(value: string): void;


    hasData(): boolean;
    clearData(): void;
    getData(): ResMessageData | undefined;
    setData(value?: ResMessageData): void;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): DealMessageResponse.AsObject;
    static toObject(includeInstance: boolean, msg: DealMessageResponse): DealMessageResponse.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: DealMessageResponse, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): DealMessageResponse;
    static deserializeBinaryFromReader(message: DealMessageResponse, reader: jspb.BinaryReader): DealMessageResponse;
}

export namespace DealMessageResponse {
    export type AsObject = {
        status: number,
        message: string,
        data?: ResMessageData.AsObject,
    }
}
