// package: message
// file: message/message.proto

import * as grpc from "grpc";
import * as message_message_pb from "../message/message_pb";

interface IMessageServiceService extends grpc.IMethodsMap {
    createLeavingMessage: ICreateLeavingMessage;
    getMessageList: IGetMessageList;
    dealMessage: IDealMessage;
}

interface ICreateLeavingMessage {
    path: string; // "/message.MessageService/CreateLeavingMessage"
    requestStream: boolean; // false
    responseStream: boolean; // false
    requestType: message_message_pb.CreateLeavingMessageRequest,
    responseType: message_message_pb.CreateLeavingMessageResponse,
    requestSerialize: (arg: message_message_pb.CreateLeavingMessageRequest) => Buffer;
    requestDeserialize: (buffer: Uint8Array) => message_message_pb.CreateLeavingMessageRequest;
    responseSerialize: (arg: message_message_pb.CreateLeavingMessageResponse) => Buffer;
    responseDeserialize: (buffer: Uint8Array) => message_message_pb.CreateLeavingMessageResponse;
}
interface IGetMessageList {
    path: string; // "/message.MessageService/GetMessageList"
    requestStream: boolean; // false
    responseStream: boolean; // false
    requestType: message_message_pb.GetMessageListRequest,
    responseType: message_message_pb.GetMessageListResponse,
    requestSerialize: (arg: message_message_pb.GetMessageListRequest) => Buffer;
    requestDeserialize: (buffer: Uint8Array) => message_message_pb.GetMessageListRequest;
    responseSerialize: (arg: message_message_pb.GetMessageListResponse) => Buffer;
    responseDeserialize: (buffer: Uint8Array) => message_message_pb.GetMessageListResponse;
}
interface IDealMessage {
    path: string; // "/message.MessageService/DealMessage"
    requestStream: boolean; // false
    responseStream: boolean; // false
    requestType: message_message_pb.DealMessageRequest,
    responseType: message_message_pb.DealMessageResponse,
    requestSerialize: (arg: message_message_pb.DealMessageRequest) => Buffer;
    requestDeserialize: (buffer: Uint8Array) => message_message_pb.DealMessageRequest;
    responseSerialize: (arg: message_message_pb.DealMessageResponse) => Buffer;
    responseDeserialize: (buffer: Uint8Array) => message_message_pb.DealMessageResponse;
}

export const MessageServiceService: IMessageServiceService;
export class MessageServiceClient extends grpc.Client {
    constructor(address: string, credentials: any, options?: grpc.IClientOptions);
    createLeavingMessage(request: message_message_pb.CreateLeavingMessageRequest, callback: (error: Error | null, response: message_message_pb.CreateLeavingMessageResponse) => void): grpc.ClientUnaryCall;
    createLeavingMessage(request: message_message_pb.CreateLeavingMessageRequest, metadata: grpc.Metadata, callback: (error: Error | null, response: message_message_pb.CreateLeavingMessageResponse) => void): grpc.ClientUnaryCall;
    getMessageList(request: message_message_pb.GetMessageListRequest, callback: (error: Error | null, response: message_message_pb.GetMessageListResponse) => void): grpc.ClientUnaryCall;
    getMessageList(request: message_message_pb.GetMessageListRequest, metadata: grpc.Metadata, callback: (error: Error | null, response: message_message_pb.GetMessageListResponse) => void): grpc.ClientUnaryCall;
    dealMessage(request: message_message_pb.DealMessageRequest, callback: (error: Error | null, response: message_message_pb.DealMessageResponse) => void): grpc.ClientUnaryCall;
    dealMessage(request: message_message_pb.DealMessageRequest, metadata: grpc.Metadata, callback: (error: Error | null, response: message_message_pb.DealMessageResponse) => void): grpc.ClientUnaryCall;
}
