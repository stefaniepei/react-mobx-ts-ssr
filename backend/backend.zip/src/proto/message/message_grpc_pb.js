// GENERATED CODE -- DO NOT EDIT!

'use strict';
var grpc = require('grpc');
var message_message_pb = require('../message/message_pb.js');
var google_api_annotations_pb = require('../google/api/annotations_pb.js');

function serialize_message_CreateLeavingMessageRequest(arg) {
  if (!(arg instanceof message_message_pb.CreateLeavingMessageRequest)) {
    throw new Error('Expected argument of type message.CreateLeavingMessageRequest');
  }
  return new Buffer(arg.serializeBinary());
}

function deserialize_message_CreateLeavingMessageRequest(buffer_arg) {
  return message_message_pb.CreateLeavingMessageRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_message_CreateLeavingMessageResponse(arg) {
  if (!(arg instanceof message_message_pb.CreateLeavingMessageResponse)) {
    throw new Error('Expected argument of type message.CreateLeavingMessageResponse');
  }
  return new Buffer(arg.serializeBinary());
}

function deserialize_message_CreateLeavingMessageResponse(buffer_arg) {
  return message_message_pb.CreateLeavingMessageResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_message_DealMessageRequest(arg) {
  if (!(arg instanceof message_message_pb.DealMessageRequest)) {
    throw new Error('Expected argument of type message.DealMessageRequest');
  }
  return new Buffer(arg.serializeBinary());
}

function deserialize_message_DealMessageRequest(buffer_arg) {
  return message_message_pb.DealMessageRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_message_DealMessageResponse(arg) {
  if (!(arg instanceof message_message_pb.DealMessageResponse)) {
    throw new Error('Expected argument of type message.DealMessageResponse');
  }
  return new Buffer(arg.serializeBinary());
}

function deserialize_message_DealMessageResponse(buffer_arg) {
  return message_message_pb.DealMessageResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_message_GetMessageListRequest(arg) {
  if (!(arg instanceof message_message_pb.GetMessageListRequest)) {
    throw new Error('Expected argument of type message.GetMessageListRequest');
  }
  return new Buffer(arg.serializeBinary());
}

function deserialize_message_GetMessageListRequest(buffer_arg) {
  return message_message_pb.GetMessageListRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_message_GetMessageListResponse(arg) {
  if (!(arg instanceof message_message_pb.GetMessageListResponse)) {
    throw new Error('Expected argument of type message.GetMessageListResponse');
  }
  return new Buffer(arg.serializeBinary());
}

function deserialize_message_GetMessageListResponse(buffer_arg) {
  return message_message_pb.GetMessageListResponse.deserializeBinary(new Uint8Array(buffer_arg));
}


var MessageServiceService = exports.MessageServiceService = {
  createLeavingMessage: {
    path: '/message.MessageService/CreateLeavingMessage',
    requestStream: false,
    responseStream: false,
    requestType: message_message_pb.CreateLeavingMessageRequest,
    responseType: message_message_pb.CreateLeavingMessageResponse,
    requestSerialize: serialize_message_CreateLeavingMessageRequest,
    requestDeserialize: deserialize_message_CreateLeavingMessageRequest,
    responseSerialize: serialize_message_CreateLeavingMessageResponse,
    responseDeserialize: deserialize_message_CreateLeavingMessageResponse,
  },
  getMessageList: {
    path: '/message.MessageService/GetMessageList',
    requestStream: false,
    responseStream: false,
    requestType: message_message_pb.GetMessageListRequest,
    responseType: message_message_pb.GetMessageListResponse,
    requestSerialize: serialize_message_GetMessageListRequest,
    requestDeserialize: deserialize_message_GetMessageListRequest,
    responseSerialize: serialize_message_GetMessageListResponse,
    responseDeserialize: deserialize_message_GetMessageListResponse,
  },
  dealMessage: {
    path: '/message.MessageService/DealMessage',
    requestStream: false,
    responseStream: false,
    requestType: message_message_pb.DealMessageRequest,
    responseType: message_message_pb.DealMessageResponse,
    requestSerialize: serialize_message_DealMessageRequest,
    requestDeserialize: deserialize_message_DealMessageRequest,
    responseSerialize: serialize_message_DealMessageResponse,
    responseDeserialize: deserialize_message_DealMessageResponse,
  },
};

exports.MessageServiceClient = grpc.makeGenericClientConstructor(MessageServiceService);
