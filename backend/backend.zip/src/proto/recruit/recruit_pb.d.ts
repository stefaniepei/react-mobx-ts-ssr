// package: recruit
// file: recruit/recruit.proto

import * as jspb from "google-protobuf";

export class Recruit extends jspb.Message { 
    getJobId(): string;
    setJobId(value: string): void;

    getStatus(): number;
    setStatus(value: number): void;

    getJobName(): string;
    setJobName(value: string): void;

    getJobType(): number;
    setJobType(value: number): void;

    getJobInfo(): string;
    setJobInfo(value: string): void;

    getLanguageType(): string;
    setLanguageType(value: string): void;

    getUpdateUserName(): string;
    setUpdateUserName(value: string): void;

    getCreateDate(): string;
    setCreateDate(value: string): void;

    getUpdateDate(): string;
    setUpdateDate(value: string): void;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Recruit.AsObject;
    static toObject(includeInstance: boolean, msg: Recruit): Recruit.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: Recruit, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Recruit;
    static deserializeBinaryFromReader(message: Recruit, reader: jspb.BinaryReader): Recruit;
}

export namespace Recruit {
    export type AsObject = {
        jobId: string,
        status: number,
        jobName: string,
        jobType: number,
        jobInfo: string,
        languageType: string,
        updateUserName: string,
        createDate: string,
        updateDate: string,
    }
}

export class ResRecruitData extends jspb.Message { 
    clearDataList(): void;
    getDataList(): Array<Recruit>;
    setDataList(value: Array<Recruit>): void;
    addData(value?: Recruit, index?: number): Recruit;

    getCount(): number;
    setCount(value: number): void;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): ResRecruitData.AsObject;
    static toObject(includeInstance: boolean, msg: ResRecruitData): ResRecruitData.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: ResRecruitData, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): ResRecruitData;
    static deserializeBinaryFromReader(message: ResRecruitData, reader: jspb.BinaryReader): ResRecruitData;
}

export namespace ResRecruitData {
    export type AsObject = {
        dataList: Array<Recruit.AsObject>,
        count: number,
    }
}

export class GetJobListRequest extends jspb.Message { 
    getStatus(): number;
    setStatus(value: number): void;

    getLanguageType(): string;
    setLanguageType(value: string): void;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): GetJobListRequest.AsObject;
    static toObject(includeInstance: boolean, msg: GetJobListRequest): GetJobListRequest.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: GetJobListRequest, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): GetJobListRequest;
    static deserializeBinaryFromReader(message: GetJobListRequest, reader: jspb.BinaryReader): GetJobListRequest;
}

export namespace GetJobListRequest {
    export type AsObject = {
        status: number,
        languageType: string,
    }
}

export class GetJobListResponse extends jspb.Message { 
    getStatus(): number;
    setStatus(value: number): void;

    getMessage(): string;
    setMessage(value: string): void;


    hasData(): boolean;
    clearData(): void;
    getData(): ResRecruitData | undefined;
    setData(value?: ResRecruitData): void;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): GetJobListResponse.AsObject;
    static toObject(includeInstance: boolean, msg: GetJobListResponse): GetJobListResponse.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: GetJobListResponse, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): GetJobListResponse;
    static deserializeBinaryFromReader(message: GetJobListResponse, reader: jspb.BinaryReader): GetJobListResponse;
}

export namespace GetJobListResponse {
    export type AsObject = {
        status: number,
        message: string,
        data?: ResRecruitData.AsObject,
    }
}

export class GetJobInfoRequest extends jspb.Message { 
    getJobId(): string;
    setJobId(value: string): void;

    getJobName(): string;
    setJobName(value: string): void;

    getJobType(): string;
    setJobType(value: string): void;

    getLanguageType(): string;
    setLanguageType(value: string): void;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): GetJobInfoRequest.AsObject;
    static toObject(includeInstance: boolean, msg: GetJobInfoRequest): GetJobInfoRequest.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: GetJobInfoRequest, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): GetJobInfoRequest;
    static deserializeBinaryFromReader(message: GetJobInfoRequest, reader: jspb.BinaryReader): GetJobInfoRequest;
}

export namespace GetJobInfoRequest {
    export type AsObject = {
        jobId: string,
        jobName: string,
        jobType: string,
        languageType: string,
    }
}

export class GetJobInfoResponse extends jspb.Message { 
    getStatus(): number;
    setStatus(value: number): void;

    getMessage(): string;
    setMessage(value: string): void;


    hasData(): boolean;
    clearData(): void;
    getData(): ResRecruitData | undefined;
    setData(value?: ResRecruitData): void;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): GetJobInfoResponse.AsObject;
    static toObject(includeInstance: boolean, msg: GetJobInfoResponse): GetJobInfoResponse.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: GetJobInfoResponse, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): GetJobInfoResponse;
    static deserializeBinaryFromReader(message: GetJobInfoResponse, reader: jspb.BinaryReader): GetJobInfoResponse;
}

export namespace GetJobInfoResponse {
    export type AsObject = {
        status: number,
        message: string,
        data?: ResRecruitData.AsObject,
    }
}

export class SetJobStopRequest extends jspb.Message { 
    getJobId(): string;
    setJobId(value: string): void;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): SetJobStopRequest.AsObject;
    static toObject(includeInstance: boolean, msg: SetJobStopRequest): SetJobStopRequest.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: SetJobStopRequest, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): SetJobStopRequest;
    static deserializeBinaryFromReader(message: SetJobStopRequest, reader: jspb.BinaryReader): SetJobStopRequest;
}

export namespace SetJobStopRequest {
    export type AsObject = {
        jobId: string,
    }
}

export class SetJobStopResponse extends jspb.Message { 
    getStatus(): number;
    setStatus(value: number): void;

    getMessage(): string;
    setMessage(value: string): void;


    hasData(): boolean;
    clearData(): void;
    getData(): ResRecruitData | undefined;
    setData(value?: ResRecruitData): void;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): SetJobStopResponse.AsObject;
    static toObject(includeInstance: boolean, msg: SetJobStopResponse): SetJobStopResponse.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: SetJobStopResponse, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): SetJobStopResponse;
    static deserializeBinaryFromReader(message: SetJobStopResponse, reader: jspb.BinaryReader): SetJobStopResponse;
}

export namespace SetJobStopResponse {
    export type AsObject = {
        status: number,
        message: string,
        data?: ResRecruitData.AsObject,
    }
}

export class PublishJobRequest extends jspb.Message { 
    getJobId(): string;
    setJobId(value: string): void;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): PublishJobRequest.AsObject;
    static toObject(includeInstance: boolean, msg: PublishJobRequest): PublishJobRequest.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: PublishJobRequest, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): PublishJobRequest;
    static deserializeBinaryFromReader(message: PublishJobRequest, reader: jspb.BinaryReader): PublishJobRequest;
}

export namespace PublishJobRequest {
    export type AsObject = {
        jobId: string,
    }
}

export class PublishJobResponse extends jspb.Message { 
    getStatus(): number;
    setStatus(value: number): void;

    getMessage(): string;
    setMessage(value: string): void;


    hasData(): boolean;
    clearData(): void;
    getData(): ResRecruitData | undefined;
    setData(value?: ResRecruitData): void;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): PublishJobResponse.AsObject;
    static toObject(includeInstance: boolean, msg: PublishJobResponse): PublishJobResponse.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: PublishJobResponse, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): PublishJobResponse;
    static deserializeBinaryFromReader(message: PublishJobResponse, reader: jspb.BinaryReader): PublishJobResponse;
}

export namespace PublishJobResponse {
    export type AsObject = {
        status: number,
        message: string,
        data?: ResRecruitData.AsObject,
    }
}

export class AddJobRequest extends jspb.Message { 
    getJobType(): string;
    setJobType(value: string): void;

    getJobName(): string;
    setJobName(value: string): void;

    getPublishUserName(): string;
    setPublishUserName(value: string): void;

    getCreateDate(): string;
    setCreateDate(value: string): void;

    getJobInfo(): string;
    setJobInfo(value: string): void;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): AddJobRequest.AsObject;
    static toObject(includeInstance: boolean, msg: AddJobRequest): AddJobRequest.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: AddJobRequest, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): AddJobRequest;
    static deserializeBinaryFromReader(message: AddJobRequest, reader: jspb.BinaryReader): AddJobRequest;
}

export namespace AddJobRequest {
    export type AsObject = {
        jobType: string,
        jobName: string,
        publishUserName: string,
        createDate: string,
        jobInfo: string,
    }
}

export class AddJobResponse extends jspb.Message { 
    getStatus(): number;
    setStatus(value: number): void;

    getMessage(): string;
    setMessage(value: string): void;


    hasData(): boolean;
    clearData(): void;
    getData(): ResRecruitData | undefined;
    setData(value?: ResRecruitData): void;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): AddJobResponse.AsObject;
    static toObject(includeInstance: boolean, msg: AddJobResponse): AddJobResponse.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: AddJobResponse, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): AddJobResponse;
    static deserializeBinaryFromReader(message: AddJobResponse, reader: jspb.BinaryReader): AddJobResponse;
}

export namespace AddJobResponse {
    export type AsObject = {
        status: number,
        message: string,
        data?: ResRecruitData.AsObject,
    }
}

export class EditJobRequest extends jspb.Message { 
    getJobType(): string;
    setJobType(value: string): void;

    getJobName(): string;
    setJobName(value: string): void;

    getPublishUserName(): string;
    setPublishUserName(value: string): void;

    getCreateDate(): string;
    setCreateDate(value: string): void;

    getJobInfo(): string;
    setJobInfo(value: string): void;

    getLanguageType(): string;
    setLanguageType(value: string): void;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): EditJobRequest.AsObject;
    static toObject(includeInstance: boolean, msg: EditJobRequest): EditJobRequest.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: EditJobRequest, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): EditJobRequest;
    static deserializeBinaryFromReader(message: EditJobRequest, reader: jspb.BinaryReader): EditJobRequest;
}

export namespace EditJobRequest {
    export type AsObject = {
        jobType: string,
        jobName: string,
        publishUserName: string,
        createDate: string,
        jobInfo: string,
        languageType: string,
    }
}

export class EditJobResponse extends jspb.Message { 
    getStatus(): number;
    setStatus(value: number): void;

    getMessage(): string;
    setMessage(value: string): void;


    hasData(): boolean;
    clearData(): void;
    getData(): ResRecruitData | undefined;
    setData(value?: ResRecruitData): void;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): EditJobResponse.AsObject;
    static toObject(includeInstance: boolean, msg: EditJobResponse): EditJobResponse.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: EditJobResponse, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): EditJobResponse;
    static deserializeBinaryFromReader(message: EditJobResponse, reader: jspb.BinaryReader): EditJobResponse;
}

export namespace EditJobResponse {
    export type AsObject = {
        status: number,
        message: string,
        data?: ResRecruitData.AsObject,
    }
}
