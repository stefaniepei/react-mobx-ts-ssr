// package: recruit
// file: recruit/recruit.proto

import * as grpc from "grpc";
import * as recruit_recruit_pb from "../recruit/recruit_pb";

interface IRecruitServiceService extends grpc.IMethodsMap {
    getJobList: IGetJobList;
    getJobInfo: IGetJobInfo;
    setJobStop: ISetJobStop;
    publishJob: IPublishJob;
    addJob: IAddJob;
    editJob: IEditJob;
}

interface IGetJobList {
    path: string; // "/recruit.RecruitService/GetJobList"
    requestStream: boolean; // false
    responseStream: boolean; // false
    requestType: recruit_recruit_pb.GetJobListRequest,
    responseType: recruit_recruit_pb.GetJobListResponse,
    requestSerialize: (arg: recruit_recruit_pb.GetJobListRequest) => Buffer;
    requestDeserialize: (buffer: Uint8Array) => recruit_recruit_pb.GetJobListRequest;
    responseSerialize: (arg: recruit_recruit_pb.GetJobListResponse) => Buffer;
    responseDeserialize: (buffer: Uint8Array) => recruit_recruit_pb.GetJobListResponse;
}
interface IGetJobInfo {
    path: string; // "/recruit.RecruitService/GetJobInfo"
    requestStream: boolean; // false
    responseStream: boolean; // false
    requestType: recruit_recruit_pb.GetJobInfoRequest,
    responseType: recruit_recruit_pb.GetJobInfoResponse,
    requestSerialize: (arg: recruit_recruit_pb.GetJobInfoRequest) => Buffer;
    requestDeserialize: (buffer: Uint8Array) => recruit_recruit_pb.GetJobInfoRequest;
    responseSerialize: (arg: recruit_recruit_pb.GetJobInfoResponse) => Buffer;
    responseDeserialize: (buffer: Uint8Array) => recruit_recruit_pb.GetJobInfoResponse;
}
interface ISetJobStop {
    path: string; // "/recruit.RecruitService/SetJobStop"
    requestStream: boolean; // false
    responseStream: boolean; // false
    requestType: recruit_recruit_pb.SetJobStopRequest,
    responseType: recruit_recruit_pb.SetJobStopResponse,
    requestSerialize: (arg: recruit_recruit_pb.SetJobStopRequest) => Buffer;
    requestDeserialize: (buffer: Uint8Array) => recruit_recruit_pb.SetJobStopRequest;
    responseSerialize: (arg: recruit_recruit_pb.SetJobStopResponse) => Buffer;
    responseDeserialize: (buffer: Uint8Array) => recruit_recruit_pb.SetJobStopResponse;
}
interface IPublishJob {
    path: string; // "/recruit.RecruitService/PublishJob"
    requestStream: boolean; // false
    responseStream: boolean; // false
    requestType: recruit_recruit_pb.PublishJobRequest,
    responseType: recruit_recruit_pb.PublishJobResponse,
    requestSerialize: (arg: recruit_recruit_pb.PublishJobRequest) => Buffer;
    requestDeserialize: (buffer: Uint8Array) => recruit_recruit_pb.PublishJobRequest;
    responseSerialize: (arg: recruit_recruit_pb.PublishJobResponse) => Buffer;
    responseDeserialize: (buffer: Uint8Array) => recruit_recruit_pb.PublishJobResponse;
}
interface IAddJob {
    path: string; // "/recruit.RecruitService/AddJob"
    requestStream: boolean; // false
    responseStream: boolean; // false
    requestType: recruit_recruit_pb.AddJobRequest,
    responseType: recruit_recruit_pb.AddJobResponse,
    requestSerialize: (arg: recruit_recruit_pb.AddJobRequest) => Buffer;
    requestDeserialize: (buffer: Uint8Array) => recruit_recruit_pb.AddJobRequest;
    responseSerialize: (arg: recruit_recruit_pb.AddJobResponse) => Buffer;
    responseDeserialize: (buffer: Uint8Array) => recruit_recruit_pb.AddJobResponse;
}
interface IEditJob {
    path: string; // "/recruit.RecruitService/EditJob"
    requestStream: boolean; // false
    responseStream: boolean; // false
    requestType: recruit_recruit_pb.EditJobRequest,
    responseType: recruit_recruit_pb.EditJobResponse,
    requestSerialize: (arg: recruit_recruit_pb.EditJobRequest) => Buffer;
    requestDeserialize: (buffer: Uint8Array) => recruit_recruit_pb.EditJobRequest;
    responseSerialize: (arg: recruit_recruit_pb.EditJobResponse) => Buffer;
    responseDeserialize: (buffer: Uint8Array) => recruit_recruit_pb.EditJobResponse;
}

export const RecruitServiceService: IRecruitServiceService;
export class RecruitServiceClient extends grpc.Client {
    constructor(address: string, credentials: any, options?: grpc.IClientOptions);
    getJobList(request: recruit_recruit_pb.GetJobListRequest, callback: (error: Error | null, response: recruit_recruit_pb.GetJobListResponse) => void): grpc.ClientUnaryCall;
    getJobList(request: recruit_recruit_pb.GetJobListRequest, metadata: grpc.Metadata, callback: (error: Error | null, response: recruit_recruit_pb.GetJobListResponse) => void): grpc.ClientUnaryCall;
    getJobInfo(request: recruit_recruit_pb.GetJobInfoRequest, callback: (error: Error | null, response: recruit_recruit_pb.GetJobInfoResponse) => void): grpc.ClientUnaryCall;
    getJobInfo(request: recruit_recruit_pb.GetJobInfoRequest, metadata: grpc.Metadata, callback: (error: Error | null, response: recruit_recruit_pb.GetJobInfoResponse) => void): grpc.ClientUnaryCall;
    setJobStop(request: recruit_recruit_pb.SetJobStopRequest, callback: (error: Error | null, response: recruit_recruit_pb.SetJobStopResponse) => void): grpc.ClientUnaryCall;
    setJobStop(request: recruit_recruit_pb.SetJobStopRequest, metadata: grpc.Metadata, callback: (error: Error | null, response: recruit_recruit_pb.SetJobStopResponse) => void): grpc.ClientUnaryCall;
    publishJob(request: recruit_recruit_pb.PublishJobRequest, callback: (error: Error | null, response: recruit_recruit_pb.PublishJobResponse) => void): grpc.ClientUnaryCall;
    publishJob(request: recruit_recruit_pb.PublishJobRequest, metadata: grpc.Metadata, callback: (error: Error | null, response: recruit_recruit_pb.PublishJobResponse) => void): grpc.ClientUnaryCall;
    addJob(request: recruit_recruit_pb.AddJobRequest, callback: (error: Error | null, response: recruit_recruit_pb.AddJobResponse) => void): grpc.ClientUnaryCall;
    addJob(request: recruit_recruit_pb.AddJobRequest, metadata: grpc.Metadata, callback: (error: Error | null, response: recruit_recruit_pb.AddJobResponse) => void): grpc.ClientUnaryCall;
    editJob(request: recruit_recruit_pb.EditJobRequest, callback: (error: Error | null, response: recruit_recruit_pb.EditJobResponse) => void): grpc.ClientUnaryCall;
    editJob(request: recruit_recruit_pb.EditJobRequest, metadata: grpc.Metadata, callback: (error: Error | null, response: recruit_recruit_pb.EditJobResponse) => void): grpc.ClientUnaryCall;
}
