// GENERATED CODE -- DO NOT EDIT!

'use strict';
var grpc = require('grpc');
var recruit_recruit_pb = require('../recruit/recruit_pb.js');
var google_api_annotations_pb = require('../google/api/annotations_pb.js');

function serialize_recruit_AddJobRequest(arg) {
  if (!(arg instanceof recruit_recruit_pb.AddJobRequest)) {
    throw new Error('Expected argument of type recruit.AddJobRequest');
  }
  return new Buffer(arg.serializeBinary());
}

function deserialize_recruit_AddJobRequest(buffer_arg) {
  return recruit_recruit_pb.AddJobRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_recruit_AddJobResponse(arg) {
  if (!(arg instanceof recruit_recruit_pb.AddJobResponse)) {
    throw new Error('Expected argument of type recruit.AddJobResponse');
  }
  return new Buffer(arg.serializeBinary());
}

function deserialize_recruit_AddJobResponse(buffer_arg) {
  return recruit_recruit_pb.AddJobResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_recruit_EditJobRequest(arg) {
  if (!(arg instanceof recruit_recruit_pb.EditJobRequest)) {
    throw new Error('Expected argument of type recruit.EditJobRequest');
  }
  return new Buffer(arg.serializeBinary());
}

function deserialize_recruit_EditJobRequest(buffer_arg) {
  return recruit_recruit_pb.EditJobRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_recruit_EditJobResponse(arg) {
  if (!(arg instanceof recruit_recruit_pb.EditJobResponse)) {
    throw new Error('Expected argument of type recruit.EditJobResponse');
  }
  return new Buffer(arg.serializeBinary());
}

function deserialize_recruit_EditJobResponse(buffer_arg) {
  return recruit_recruit_pb.EditJobResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_recruit_GetJobInfoRequest(arg) {
  if (!(arg instanceof recruit_recruit_pb.GetJobInfoRequest)) {
    throw new Error('Expected argument of type recruit.GetJobInfoRequest');
  }
  return new Buffer(arg.serializeBinary());
}

function deserialize_recruit_GetJobInfoRequest(buffer_arg) {
  return recruit_recruit_pb.GetJobInfoRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_recruit_GetJobInfoResponse(arg) {
  if (!(arg instanceof recruit_recruit_pb.GetJobInfoResponse)) {
    throw new Error('Expected argument of type recruit.GetJobInfoResponse');
  }
  return new Buffer(arg.serializeBinary());
}

function deserialize_recruit_GetJobInfoResponse(buffer_arg) {
  return recruit_recruit_pb.GetJobInfoResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_recruit_GetJobListRequest(arg) {
  if (!(arg instanceof recruit_recruit_pb.GetJobListRequest)) {
    throw new Error('Expected argument of type recruit.GetJobListRequest');
  }
  return new Buffer(arg.serializeBinary());
}

function deserialize_recruit_GetJobListRequest(buffer_arg) {
  return recruit_recruit_pb.GetJobListRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_recruit_GetJobListResponse(arg) {
  if (!(arg instanceof recruit_recruit_pb.GetJobListResponse)) {
    throw new Error('Expected argument of type recruit.GetJobListResponse');
  }
  return new Buffer(arg.serializeBinary());
}

function deserialize_recruit_GetJobListResponse(buffer_arg) {
  return recruit_recruit_pb.GetJobListResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_recruit_PublishJobRequest(arg) {
  if (!(arg instanceof recruit_recruit_pb.PublishJobRequest)) {
    throw new Error('Expected argument of type recruit.PublishJobRequest');
  }
  return new Buffer(arg.serializeBinary());
}

function deserialize_recruit_PublishJobRequest(buffer_arg) {
  return recruit_recruit_pb.PublishJobRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_recruit_PublishJobResponse(arg) {
  if (!(arg instanceof recruit_recruit_pb.PublishJobResponse)) {
    throw new Error('Expected argument of type recruit.PublishJobResponse');
  }
  return new Buffer(arg.serializeBinary());
}

function deserialize_recruit_PublishJobResponse(buffer_arg) {
  return recruit_recruit_pb.PublishJobResponse.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_recruit_SetJobStopRequest(arg) {
  if (!(arg instanceof recruit_recruit_pb.SetJobStopRequest)) {
    throw new Error('Expected argument of type recruit.SetJobStopRequest');
  }
  return new Buffer(arg.serializeBinary());
}

function deserialize_recruit_SetJobStopRequest(buffer_arg) {
  return recruit_recruit_pb.SetJobStopRequest.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_recruit_SetJobStopResponse(arg) {
  if (!(arg instanceof recruit_recruit_pb.SetJobStopResponse)) {
    throw new Error('Expected argument of type recruit.SetJobStopResponse');
  }
  return new Buffer(arg.serializeBinary());
}

function deserialize_recruit_SetJobStopResponse(buffer_arg) {
  return recruit_recruit_pb.SetJobStopResponse.deserializeBinary(new Uint8Array(buffer_arg));
}


var RecruitServiceService = exports.RecruitServiceService = {
  getJobList: {
    path: '/recruit.RecruitService/GetJobList',
    requestStream: false,
    responseStream: false,
    requestType: recruit_recruit_pb.GetJobListRequest,
    responseType: recruit_recruit_pb.GetJobListResponse,
    requestSerialize: serialize_recruit_GetJobListRequest,
    requestDeserialize: deserialize_recruit_GetJobListRequest,
    responseSerialize: serialize_recruit_GetJobListResponse,
    responseDeserialize: deserialize_recruit_GetJobListResponse,
  },
  getJobInfo: {
    path: '/recruit.RecruitService/GetJobInfo',
    requestStream: false,
    responseStream: false,
    requestType: recruit_recruit_pb.GetJobInfoRequest,
    responseType: recruit_recruit_pb.GetJobInfoResponse,
    requestSerialize: serialize_recruit_GetJobInfoRequest,
    requestDeserialize: deserialize_recruit_GetJobInfoRequest,
    responseSerialize: serialize_recruit_GetJobInfoResponse,
    responseDeserialize: deserialize_recruit_GetJobInfoResponse,
  },
  setJobStop: {
    path: '/recruit.RecruitService/SetJobStop',
    requestStream: false,
    responseStream: false,
    requestType: recruit_recruit_pb.SetJobStopRequest,
    responseType: recruit_recruit_pb.SetJobStopResponse,
    requestSerialize: serialize_recruit_SetJobStopRequest,
    requestDeserialize: deserialize_recruit_SetJobStopRequest,
    responseSerialize: serialize_recruit_SetJobStopResponse,
    responseDeserialize: deserialize_recruit_SetJobStopResponse,
  },
  publishJob: {
    path: '/recruit.RecruitService/PublishJob',
    requestStream: false,
    responseStream: false,
    requestType: recruit_recruit_pb.PublishJobRequest,
    responseType: recruit_recruit_pb.PublishJobResponse,
    requestSerialize: serialize_recruit_PublishJobRequest,
    requestDeserialize: deserialize_recruit_PublishJobRequest,
    responseSerialize: serialize_recruit_PublishJobResponse,
    responseDeserialize: deserialize_recruit_PublishJobResponse,
  },
  addJob: {
    path: '/recruit.RecruitService/AddJob',
    requestStream: false,
    responseStream: false,
    requestType: recruit_recruit_pb.AddJobRequest,
    responseType: recruit_recruit_pb.AddJobResponse,
    requestSerialize: serialize_recruit_AddJobRequest,
    requestDeserialize: deserialize_recruit_AddJobRequest,
    responseSerialize: serialize_recruit_AddJobResponse,
    responseDeserialize: deserialize_recruit_AddJobResponse,
  },
  editJob: {
    path: '/recruit.RecruitService/EditJob',
    requestStream: false,
    responseStream: false,
    requestType: recruit_recruit_pb.EditJobRequest,
    responseType: recruit_recruit_pb.EditJobResponse,
    requestSerialize: serialize_recruit_EditJobRequest,
    requestDeserialize: deserialize_recruit_EditJobRequest,
    responseSerialize: serialize_recruit_EditJobResponse,
    responseDeserialize: deserialize_recruit_EditJobResponse,
  },
};

exports.RecruitServiceClient = grpc.makeGenericClientConstructor(RecruitServiceService);
