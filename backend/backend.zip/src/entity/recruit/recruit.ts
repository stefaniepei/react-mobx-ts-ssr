import {Entity, ObjectID, ObjectIdColumn, Column} from "typeorm";

@Entity()
export class Recruit {

  @ObjectIdColumn()
  id: ObjectID;  //  职位id

  @Column()
  status: number;  //  招聘信息状态: 0.停用，1.启用

  @Column()
  createDate: Date;   // 创建时间

  @Column()
  updateUserName: string;   //  编辑人

  @Column()
  updateDate: Date;   //  编辑时间

}


