import {Entity, ObjectID, ObjectIdColumn, Column} from "typeorm";

@Entity()
export class RecruitDetail {

  @ObjectIdColumn()
  id: ObjectID;

  @Column()
  jobId: string;  //  职位id

  @Column()
  jobName: string;  //  职位名

  @Column()
  jobType: number;  //  职位类型

  @Column()
  jobInfo: string;  //  招聘信息

  @Column()
  languageType: string;  //  语言类型
}


