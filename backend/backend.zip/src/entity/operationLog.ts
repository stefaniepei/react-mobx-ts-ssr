import {Entity, ObjectID, ObjectIdColumn, Column} from "typeorm";

@Entity()
export class Message {

  @ObjectIdColumn()
  id: ObjectID;

  @Column()
  type: string;   //  操作类型：1：新增，2：编辑，3：删除

  @Column()
  user_id: string;   //  用户id
  @Column()
  user_name: string;   //  用户名
  @Column()
  time: string;  //  操作时间


}
