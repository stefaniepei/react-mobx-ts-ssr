import {Entity, ObjectID, ObjectIdColumn, Column} from "typeorm";

@Entity()
export class Message {

  @ObjectIdColumn()
  id: ObjectID;

  @Column()
  userName: string;   //  用户名

  @Column()
  userEmail: string;   //  用户email

  @Column()
  userPhone: string;   //  用户手机

  @Column()
  userAddress: string;  //  用户地址

  @Column()
  gameType: string;    //  游戏类型

  @Column()
  messageStatus: number;   //  留言状态

  @Column()
  dealUserName: string;   //  处理留言的用户名

  @Column()
  dealDate: Date;   //  处理日期

  @Column()
  createDate: Date;  //  创建时间

  @Column()
  userExperience: string;   //  用户工作经验描述

  @Column()
  gameInfo: string;    //  游戏介绍

  @Column()
  message: string;   //  留言消息

  @Column()
  messageType: number;   //  留言类型：1: 孵化，2: 发行，3: 品牌公关，4: 其他


}
