import * as LibPath from 'path'
import * as Koa from 'koa'
import * as koaBodyParser from 'koa-bodyparser'
import * as koaCors from 'koa2-cors'
import * as staticServer from 'koa-static'
import { KoaInstrumentation } from 'zipkin-instrumentation-koa'
import RouterLoader from '../router/Router'
import { ConfigHelper } from '../helper/ConfigHelper'
import { TracerHelper } from '../helper/TracerHelper'
import compressHandler from '../middleware/compressHandler'
import jwtHandler from '../middleware/jwtHandler'
import errorHandler from '../middleware/errorHandler'
import requestIdHandler from '../middleware/requestIdHandler'
import requestTimer from '../middleware/requestTimer'
import { unlessUrls } from '../configs/unlessUrls'
import { initMongodbClient } from '../lib/mongodbClient'

// import notFoundHandler from '../middleware/notFoundHandler';

import * as path from 'path'
import * as fs from 'fs-extra'
import * as KoaStatic from 'koa-static'
import * as convert from 'koa-convert'

export default class GWDemo {
  private _initialized: boolean
  public app: Koa

  constructor() {
    this._initialized = false
  }

  public async init(isDev: boolean = false): Promise<any> {
    const configPath = (isDev)
      ? LibPath.join(__dirname, '..', '..', 'config.dev.json')
      : LibPath.join(__dirname, '..', '..', 'config.json')

    await ConfigHelper.instance().init(configPath)
    await TracerHelper.instance().init()
    await RouterLoader.instance().init()
    const options = ConfigHelper.instance().getOption()

    await initMongodbClient()

    const app = new Koa()
    app.use(KoaInstrumentation.middleware(TracerHelper.instance().getTraceInfo()))


    // static files serving
    app.use(staticServer(options.staticPath, { maxage: options.maxAge || 0 }))

    // enable Access-Control-Allow-Origin
    const enableCors = options.enableCors || false
    if (enableCors === true) {
      app.use(koaCors({ origin: '*' }))
    }
    // enable Gzip
    const enableGzip = options.enableGzip || true
    if (enableGzip === true) {
      app.use(compressHandler.register(options.compressOpt))
    }

    //  add request id in app
    app.use(requestIdHandler.register())
    //  request timer
    app.use(requestTimer.register())
    // 404 handler
    //app.use(notFoundHandler.register())
    //  error handle:500
    app.use(errorHandler.register())
    //  post body parser
    app.use(koaBodyParser({ formLimit: '2048kb' }))
    // add jwt if open jwt auth
    const enableJWT = options.enableJWT || false
    if (enableJWT === true) {
      app.use(jwtHandler.register({ secret: options.jwtSecret }, []).unless(unlessUrls))
    }
    app.use(RouterLoader.instance().getRouter().routes())


    app.use(convert(KoaStatic('../../../dist')))
    console.log(1, path.join(__dirname, '../../../', 'dist', 'server.bundle.js'))

    app.use(async(ctx: any, next) => {
      let staticPath = path.join(__dirname, '../../../', 'dist')
      let distServer = require(staticPath + '/server.bundle.js').default
      console.log(2, distServer)
      const res: any = await distServer(this, staticPath)
      console.log(3, res)
      const { originalUrl } = ctx
      try {
        await ctx.render('index', { initialView: res.initialView, initialState: res.initialState, initialTitle: res.initialTitle, initialMeta: res.initialMeta })
      } catch (e) {
        ctx.body = e.message
      }
      next && await next()
    })


    // app.use(convert(function*(next) {
    //   let staticPath = path.join(__dirname, '../../../', 'dist')
    //   let distServer = require(staticPath + '/server.bundle.js').default
    //   const res = yield distServer(this, staticPath)
    //   if (res.status === 302) {
    //     this.status = res.status
    //     this.redirect(res.redirectPath)
    //   } else if (res.status === 200) {
    //     this.body = res.body
    //   } else {
    //     this.body = res.body
    //     this.status = res.status
    //   }
    // }))

    // app.use(convert(function*(next) {

    //   console.log(1, KoaStatic('../../../dist'))
    //   console.log(2, path.join(__dirname, '../../../', 'dist', 'server.bundle.js'))
    //   this.body = fs.readFileSync(path.join(__dirname, '../../../', 'dist', 'server.bundle.js'), { 'encoding': 'utf8' })
    //   yield next
    // }))




    this.app = app

    this._initialized = true

    return Promise.resolve()
  }

  public start(): void {
    if (!this._initialized) {
      return
    }

    const options = ConfigHelper.instance().getOption()
    const host = options.host
    const port = options.port + 1
    this.app.listen(port, options.host, () => {
      console.log(`API Gateway Start, Address: ${host}:${port}!`)
    })
  }
}
