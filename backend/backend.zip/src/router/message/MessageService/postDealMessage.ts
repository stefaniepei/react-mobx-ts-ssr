import {GatewayApiBase, GatewayContext, MiddlewareNext} from "sasdn";
import {DealMessageResponse, DealMessageRequest, ResMessageData, Message} from "../../../proto/message/message_pb";
import * as messageLogic from "../../../logic/message/messageLogic";
import {Exception} from '../../../lib/Exception';

interface RequestParams {
    body: DealMessageRequest.AsObject;
}

class PostDealMessage extends GatewayApiBase {
    constructor() {
        super();
        this.method = 'post';
        this.uri = '/api/v1/message/bkSetComplete';
        this.type = 'application/json; charset=utf-8';
        this.schemaDefObj = {
            body: {
                type: 'object',
                required: true,
                schema: {
                    messageId: {
                        type: 'string',
                        required: false,
                    },
                },
            },
        };
    }

    public async handle(ctx: GatewayContext, next: MiddlewareNext, params: RequestParams): Promise<DealMessageResponse.AsObject> {
      console.log(`[Gateway] /v1/message/bkSetComplete, params: ${JSON.stringify(params)}`);
      let response: DealMessageResponse.AsObject;
      if (process.env.NODE_ENV === 'development' && params.body.hasOwnProperty('mock') && params.body['mock'] == 1) {
        // await this.sleep(1);
        response = await this.handleMock(ctx, next, params);
      } else {
        response = await messageLogic.messageLogic.dealLeavingMessage(ctx, next, params)
          .then((response) => {
            console.log(`[Gateway] /v1/message/bkSetComplete, response: ${JSON.stringify(response)}`);
            return response.toObject();
          }).catch((err) => {
            console.log(`[Gateway] /v1/message/bkSetComplete, error: ${err.message}`);
            return Exception.parseErrorMsg(err);
          });
      }

      return Promise.resolve(response);
    }

  public async handleMock(ctx: GatewayContext, next: MiddlewareNext, params: RequestParams): Promise<DealMessageResponse.AsObject> {
    const message: Message.AsObject = {
      messageId: '1233333',
      userName: 'test11',
      userEmail: '123456789@gmail.com',
      userPhone: '12345678911',
      userAddress: '上海',
      gameType: '测试',
      messageStatus: 1,
      dealUserName: 'admin',
      dealDate: '1511242639',
      createDate: '1511242639',
      userExperience: '测试1234',
      gameInfo: '测试',
      message: '',
      messageType: 1
    };


    const messageList = [];
    messageList.push(message);

    const resData: ResMessageData.AsObject = {
      dataList: messageList,
      count: 1
    }

    let response: DealMessageResponse.AsObject = {
      status: 0,
      message: 'success',
      data: resData
    };
    return Promise.resolve(response);
  }
  sleep (time) {
    return new Promise(function (resolve, reject) {
      setTimeout(function () {
        resolve();
      }, time);
    })
  };

}

export const api = new PostDealMessage();
