import {GatewayApiBase, GatewayContext, MiddlewareNext} from "sasdn";
import {CreateLeavingMessageResponse, CreateLeavingMessageRequest, } from "../../../proto/message/message_pb";
import * as messageLogic from "../../../logic/message/messageLogic";
import {Exception} from '../../../lib/Exception';

interface RequestParams {
    body: CreateLeavingMessageRequest.AsObject;
}

class PostCreateLeavingMessage extends GatewayApiBase {
    constructor() {
        super();
        this.method = 'post';
        this.uri = '/api/v1/message/leaveMessage';
        this.type = 'application/json; charset=utf-8';
        this.schemaDefObj = {
            body: {
                type: 'object',
                required: true,
                schema: {
                    userName: {
                        type: 'string',
                        required: false,
                    },
                    userEmail: {
                        type: 'string',
                        required: false,
                    },
                    userPhone: {
                        type: 'string',
                        required: false,
                    },
                    userAddress: {
                        type: 'string',
                        required: false,
                    },
                    gameType: {
                        type: 'string',
                        required: false,
                    },
                    userExperience: {
                        type: 'string',
                        required: false,
                    },
                    gameInfo: {
                        type: 'string',
                        required: false,
                    },
                    message: {
                        type: 'string',
                        required: false,
                    },
                    messageType: {
                        type: 'number',
                        required: false,
                    },
                },
            },
        };
    }

    public async handle(ctx: GatewayContext, next: MiddlewareNext, params: RequestParams): Promise<CreateLeavingMessageResponse.AsObject> {
      console.log(`[Gateway] /v1/message/leaveMessage: ${JSON.stringify(params)}`);
      let response: CreateLeavingMessageResponse.AsObject;
      response = await messageLogic.messageLogic.createLeavingMessage(ctx, next, params)
        .then((response) => {
          console.log(`[Gateway] /v1/message/leaveMessage, response: ${JSON.stringify(response)}`);
          return response.toObject();
        }).catch((err) => {
          console.log(`[Gateway] /v1/message/leaveMessage, error: ${err.message}`);
          return Exception.parseErrorMsg(err);
        });

      return Promise.resolve(response);
    }
}

export const api = new PostCreateLeavingMessage();
