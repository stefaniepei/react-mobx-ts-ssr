import {GatewayApiBase, GatewayContext, MiddlewareNext} from "sasdn";
import {GetMessageListResponse, GetMessageListRequest, ResMessageData, Message} from "../../../proto/message/message_pb";
import * as messageLogic from "../../../logic/message/messageLogic";
import {Exception} from '../../../lib/Exception';

interface RequestParams {
    body: GetMessageListRequest.AsObject;
}

class PostGetMessageList extends GatewayApiBase {
    constructor() {
        super();
        this.method = 'post';
        this.uri = '/api/v1/message/bkGetMessageList';
        this.type = 'application/json; charset=utf-8';
        this.schemaDefObj = {
            body: {
                type: 'object',
                required: true,
                schema: {
                    messageType: {
                        type: 'number',
                        required: false,
                    },
                },
            },
        };
    }

    public async handle(ctx: GatewayContext, next: MiddlewareNext, params: RequestParams): Promise<GetMessageListResponse.AsObject> {
      console.log(`[Gateway] /v1/message/bkGetMessageList, params: ${JSON.stringify(params)}`);
      let response: GetMessageListResponse.AsObject;
      if (process.env.NODE_ENV === 'development' && params.body.hasOwnProperty('mock') && params.body['mock'] == 1) {
        // await this.sleep(1);
        response = await this.handleMock(ctx, next, params);
      } else {
        response = await messageLogic.messageLogic.getMessageList(ctx, next, params)
          .then((response) => {
            console.log(`[Gateway] /v1/message/bkGetMessageList, response: ${JSON.stringify(response)}`);
            return response.toObject();
          }).catch((err) => {
            console.log(`[Gateway] /v1/message/bkGetMessageList, error: ${err.message}`);
            return Exception.parseErrorMsg(err);
          });
      }

      return Promise.resolve(response);
    }

  public async handleMock(ctx: GatewayContext, next: MiddlewareNext, params: RequestParams): Promise<GetMessageListResponse.AsObject> {
    const message_1: Message.AsObject = {
      messageId: '111111111111',
      userName: 'test11',
      userEmail: '123456789@gmail.com',
      userPhone: '12345678911',
      userAddress: '上海',
      gameType: '测试',
      messageStatus: 1,
      dealUserName: 'admin',
      dealDate: '1511242639',
      createDate: '1511242639',
      userExperience: '测试1234',
      gameInfo: '测试',
      message: '',
      messageType: 1,
    };

    const message_2: Message.AsObject = {
      messageId: '22222222222',
      userName: 'test22',
      userEmail: '2222222@gmail.com',
      userPhone: '222222',
      userAddress: '苏州',
      gameType: '测试2222',
      messageStatus: 0,
      dealUserName: 'admin',
      dealDate: '2222222',
      createDate: '15112222242639',
      userExperience: '2222',
      gameInfo: '222',
      message: '',
      messageType: 1,
    };

    const messageList = [];
    for (let index = 0; index < 10; index++) {
      if (index % 2) {
        messageList.push(message_1)
      } else {
        messageList.push(message_2)
      }
    }
    const resData: ResMessageData.AsObject = {
      dataList: messageList,
      count: 100
    }

    let response: GetMessageListResponse.AsObject = {
      status: 0,
      message: 'success',
      data: resData
    };
    return Promise.resolve(response);
  }

}

export const api = new PostGetMessageList();
