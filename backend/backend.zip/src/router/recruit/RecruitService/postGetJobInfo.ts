import {GatewayApiBase, GatewayContext, MiddlewareNext} from "sasdn";
import {GetJobInfoResponse, GetJobInfoRequest, } from "../../../proto/recruit/recruit_pb";
import * as recruitLogic from "../../../logic/recruit/recruitLogic";
import {Exception} from '../../../lib/Exception';

interface RequestParams {
    body: GetJobInfoRequest.AsObject;
}

class PostGetJobInfo extends GatewayApiBase {
    constructor() {
        super();
        this.method = 'post';
        this.uri = '/api/v1/recruit/getJobInfo';
        this.type = 'application/json; charset=utf-8';
        this.schemaDefObj = {
            body: {
                type: 'object',
                required: true,
                schema: {
                    jobId: {
                        type: 'string',
                        required: false,
                    },
                    jobName: {
                        type: 'string',
                        required: false,
                    },
                    jobType: {
                        type: 'string',
                        required: false,
                    },
                    languageType: {
                        type: 'string',
                        required: false,
                    },
                },
            },
        };
    }

    public async handle(ctx: GatewayContext, next: MiddlewareNext, params: RequestParams): Promise<GetJobInfoResponse.AsObject> {
      console.log(`[Gateway] /v1/recruit/getJobInfo, params: ${JSON.stringify(params)}`);
      let response: GetJobInfoResponse.AsObject;
      if (process.env.NODE_ENV === 'development' && params.body.hasOwnProperty('mock') && params.body['mock'] == 1) {
        // await this.sleep(1);
        response = await this.handleMock(ctx, next, params);
      } else {
        response = await recruitLogic.recruitLogic.getJobInfo(ctx, next, params)
          .then((response) => {
            return response.toObject();
          }).catch((err) => {
            console.log(`[Gateway] /v1/recruit/getJobInfo, error: ${err.message}`);
            return Exception.parseErrorMsg(err);
          });
      }

      return Promise.resolve(response);
    }

  public async handleMock(ctx: GatewayContext, next: MiddlewareNext, params: RequestParams): Promise<GetJobInfoResponse.AsObject> {
    return
  }

}

export const api = new PostGetJobInfo();
