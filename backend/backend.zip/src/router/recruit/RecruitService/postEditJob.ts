import {GatewayApiBase, GatewayContext, MiddlewareNext} from "sasdn";
import {EditJobResponse, EditJobRequest, } from "../../../proto/recruit/recruit_pb";
import * as recruitLogic from "../../../logic/recruit/recruitLogic";
import {Exception} from '../../../lib/Exception';

interface RequestParams {
    body: EditJobRequest.AsObject;
}

class PostEditJob extends GatewayApiBase {
    constructor() {
        super();
        this.method = 'post';
        this.uri = '/api/v1/recruit/bkEditJob';
        this.type = 'application/json; charset=utf-8';
        this.schemaDefObj = {
            body: {
                type: 'object',
                required: true,
                schema: {
                    jobType: {
                        type: 'string',
                        required: false,
                    },
                    jobName: {
                        type: 'string',
                        required: false,
                    },
                    publishUserName: {
                        type: 'string',
                        required: false,
                    },
                    createDate: {
                        type: 'string',
                        required: false,
                    },
                    jobInfo: {
                        type: 'string',
                        required: false,
                    },
                    languageType: {
                        type: 'string',
                        required: false,
                    },
                },
            },
        };
    }

    public async handle(ctx: GatewayContext, next: MiddlewareNext, params: RequestParams): Promise<EditJobResponse.AsObject> {
      console.log(`[Gateway] /v1/recruit/bkEditJob, params: ${JSON.stringify(params)}`);
      let response: EditJobResponse.AsObject;
      if (process.env.NODE_ENV === 'development' && params.body.hasOwnProperty('mock') && params.body['mock'] == 1) {
        // await this.sleep(1);
        response = await this.handleMock(ctx, next, params);
      } else {
        response = await recruitLogic.recruitLogic.editJob(ctx, next, params)
          .then((response) => {
            return response.toObject();
          }).catch((err) => {
            console.log(`[Gateway] /v1/recruit/bkEditJob, error: ${err.message}`);
            return Exception.parseErrorMsg(err);
          });
      }

      return Promise.resolve(response);
    }

  public async handleMock(ctx: GatewayContext, next: MiddlewareNext, params: RequestParams): Promise<EditJobResponse.AsObject> {
    return
  }

}

export const api = new PostEditJob();
