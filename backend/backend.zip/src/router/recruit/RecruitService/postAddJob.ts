import {GatewayApiBase, GatewayContext, MiddlewareNext} from "sasdn";
import {AddJobResponse, AddJobRequest, Recruit, ResRecruitData} from "../../../proto/recruit/recruit_pb";
import * as recruitLogic from "../../../logic/recruit/recruitLogic";
import {Exception} from '../../../lib/Exception';

interface RequestParams {
    body: AddJobRequest.AsObject;
}

class PostAddJob extends GatewayApiBase {
    constructor() {
        super();
        this.method = 'post';
        this.uri = '/api/v1/recruit/bkAddJob';
        this.type = 'application/json; charset=utf-8';
        this.schemaDefObj = {
            body: {
                type: 'object',
                required: true,
                schema: {
                    jobType: {
                        type: 'string',
                        required: false,
                    },
                    jobName: {
                        type: 'string',
                        required: false,
                    },
                    publishUserName: {
                        type: 'string',
                        required: false,
                    },
                    createDate: {
                        type: 'string',
                        required: false,
                    },
                    jobInfo: {
                        type: 'string',
                        required: false,
                    },
                },
            },
        };
    }

    public async handle(ctx: GatewayContext, next: MiddlewareNext, params: RequestParams): Promise<AddJobResponse.AsObject> {
      console.log(`[Gateway] /v1/recruit/bkAddJob, params: ${JSON.stringify(params)}`);
      let response: AddJobResponse.AsObject;
      if (process.env.NODE_ENV === 'development' && params.body.hasOwnProperty('mock') && params.body['mock'] == 1) {
        // await this.sleep(1);
        response = await this.handleMock(ctx, next, params);
      } else {
        response = await recruitLogic.recruitLogic.addJob(ctx, next, params)
          .then((response) => {
            return response.toObject();
          }).catch((err) => {
            console.log(`[Gateway] /v1/recruit/bkAddJob, error: ${err.message}`);
            return Exception.parseErrorMsg(err);
          });
      }

      return Promise.resolve(response);
    }

  public async handleMock(ctx: GatewayContext, next: MiddlewareNext, params: RequestParams): Promise<AddJobResponse.AsObject> {
    const jobInfo: Recruit.AsObject = {
      jobId: '123456',
      status: 0,
      jobName: '小猿',
      jobType: 1,
      jobInfo: '会使用。。。',
      languageType: 'en',
      updateUserName: '',
      createDate: '',
      updateDate: '',
    };

    const jobList = [];
    jobList.push(jobInfo);

    const resData: ResRecruitData.AsObject = {
      dataList: jobList,
      count: 1
    }

    let response: AddJobResponse.AsObject = {
      status: 0,
      message: 'success',
      data: resData
    };

    return Promise.resolve(response);

  }
}

export const api = new PostAddJob();
