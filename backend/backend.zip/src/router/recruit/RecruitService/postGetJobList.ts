import {GatewayApiBase, GatewayContext, MiddlewareNext} from "sasdn";
import {GetJobListResponse, GetJobListRequest, } from "../../../proto/recruit/recruit_pb";
import * as recruitLogic from "../../../logic/recruit/recruitLogic";
import {Exception} from '../../../lib/Exception';

interface RequestParams {
    body: GetJobListRequest.AsObject;
}

class PostGetJobList extends GatewayApiBase {
    constructor() {
        super();
        this.method = 'post';
        this.uri = '/api/v1/recruit/getJobList';
        this.type = 'application/json; charset=utf-8';
        this.schemaDefObj = {
            body: {
                type: 'object',
                required: true,
                schema: {
                    status: {
                        type: 'number',
                        required: false,
                    },
                    languageType: {
                        type: 'string',
                        required: false,
                    },
                },
            },
        };
    }

    public async handle(ctx: GatewayContext, next: MiddlewareNext, params: RequestParams): Promise<GetJobListResponse.AsObject> {
      console.log(`[Gateway] /v1/recruit/getJobList, params: ${JSON.stringify(params)}`);
      let response: GetJobListResponse.AsObject;
      if (process.env.NODE_ENV === 'development' && params.body.hasOwnProperty('mock') && params.body['mock'] == 1) {
        // await this.sleep(1);
        response = await this.handleMock(ctx, next, params);
      } else {
        response = await recruitLogic.recruitLogic.getJobList(ctx, next, params)
          .then((response) => {
            return response.toObject();
          }).catch((err) => {
            console.log(`[Gateway] /v1/recruit/getJobList, error: ${err.message}`);
            return Exception.parseErrorMsg(err);
          });
      }

      return Promise.resolve(response);
    }

  public async handleMock(ctx: GatewayContext, next: MiddlewareNext, params: RequestParams): Promise<GetJobListResponse.AsObject> {
    return
  }

}

export const api = new PostGetJobList();
